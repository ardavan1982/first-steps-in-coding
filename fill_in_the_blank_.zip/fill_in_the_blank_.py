import string

# Quiz 1 - Easy
quiz_1 = """Let's talk about strings, lists, and tupples. A string is a
sequence of characters whereas a list is a sequence of anything. The difference
between list and tupples is that lists are mutable in contrast to tupples
which are not, which leads to a very different use of each of these two. A
dictionary is also an extremely useful tool. A dictionary is sort of list but
which allows to map keys to values, such as in the updated code version of this
quiz, which allowed me to get rid of my global variables and get a much more
elegant and solid code. """

answer_quiz_1 = ['string','list','tupple','dictionary']

# Quiz 2 - Medium
quiz_2 = """There are a few different typical list operations such as append,"+", len,
and index. "append" allows to change the list by adding one element to it. The "+"
operator is used to create a new list by concatenating other lists. "len" counts
the number of outer (non-nested) elements of the list. And "index" can also be
very useful as it provides the position of one looked for element in the list."""

answer_quiz_2 = ['append','+','len','index']

#Quiz 3 - Hard
quiz_3 = """debugging is a crucial task for a programmer, because it is used constantly
by all programmers in their process of writing a functional software. So it is
instrumental to be very effective and efficient in debugging. The best practices
usually are: test as you go (mini micro debugging along the way), examine error
messages (starting from the last line "tracebacks"), work from example code
and make sure the example code works, check (usually with prints) intermediate
results, keep & compare old versions (in git hub). Previously written comments
are also very useful in order to help you understand your code while debugging"""

answer_quiz_3 = ['debugging','test','example','comments']

# Dictionary to map each quiz string to its level, ditto for the answer list.
quiz = {'easy': quiz_1,'medium': quiz_2,'hard': quiz_3}
answer_list = {'easy': answer_quiz_1,'medium': answer_quiz_2,'hard': answer_quiz_3}


def prompt_quiz():
	""" transforms and returns the quiz ready to fill of chosen level
	inputs: no inputs as the user chosen level is in the called quiz_level function
	outputs: the prompt version of the quiz
	"""
	answer_blank_number = 1
	prompt_quiz = quiz[quiz_level(user_input0)]
	for answer in answer_list[quiz_level(user_input0)] :
		fill_in = '__ %s __'% (answer_blank_number)
		answer_blank_number += 1
		prompt_quiz = string.replace(prompt_quiz,answer,fill_in)
	return prompt_quiz


def quiz_level(user_input0):
	""" returns the chosen level quiz
	inputs: the user desired level typed in the Shell
	outputs: the chosen_level
	"""
	index = 0 # to stop if correct level answer
	chosen_level = ''

	while index == 0:
		user_input0 = user_input0.lower()
		user_input0 = user_input0.strip(' ')
		if user_input0 == 'easy':
			chosen_level = 'easy'
			index += 1
		elif user_input0 == 'medium':
			chosen_level = 'medium'
			index += 1
		elif user_input0 == 'hard':
			chosen_level = 'hard'
			index += 1
		else: user_input0 = raw_input('Type-in error - Please try again? ')
	return chosen_level


def play_quiz():
	""" runs the game
	inputs: no inputs as the user has set previously the desired playing level
	outputs: the filled version of the quiz_number (and/or intermediate game messages)
	"""
	ongoing_version = prompt_quiz()
	for answer in answer_list[quiz_level(user_input0)]:
		answer_number = answer_list[quiz_level(user_input0)].index(answer) + 1
		index = 0
		while index < 1:
			print '\n%s\n'%(ongoing_version)
			user_input1 = raw_input('What word should fill in the blanks %s? '% (answer_number))
			user_input1 = user_input1.lower()
			user_input1 = user_input1.strip(' ')
			if user_input1 == answer:
				index += 1 # used to move to next word
				ongoing_version = string.replace(ongoing_version,'__ %s __'%(answer_number),user_input1)
				if answer == answer_list[quiz_level(user_input0)][len(answer_list[quiz_level(user_input0)])-1]:
					print '\nCongratulations the game is over! You rocked it!\n'
					print '\n%s\n'%(ongoing_version)


#Here is where the game runs and calls on the functions previously defined
user_input0 = raw_input('Choose a level: easy, medium or hard? ')
play_quiz()



