import media
import fresh_tomatoes

rocky = media.Movie("Rocky",
	"A fighter of life",
	"http://cache2.allpostersimages.com/p/LRG/56/5698/2SSUG00Z/posters/rocky-movie-score-arms-up.jpg",
	"https://www.youtube.com/watch?v=3VUblDwa648",
	"https://www.youtube.com/watch?v=dmqwi9hReww",
	"http://www.imdb.com/title/tt0075148/?ref_=nv_sr_1")

fight_club = media.Movie("Fight Club",
	"A society changer",
	"http://cache2.allpostersimages.com/p/LRG/20/2059/8AD2D00Z/posters/fight-club.jpg",
	"https://www.youtube.com/watch?v=5PSNL1qE6VY",
	"https://www.youtube.com/watch?v=9HYifa74Ggk",
	"http://www.imdb.com/title/tt0137523/?ref_=nv_sr_1")

terminator2 = media.Movie("Terminator 2",
	"Fight between mankind & Robots",
	"http://img.goldposter.com/2015/04/Terminator-2-Judgment-Day_poster_goldposter_com_3-508x721.jpg",
	"https://www.youtube.com/watch?v=-W8CegO_Ixw",
	"https://www.youtube.com/watch?v=FZIVMf9Lpj8",
	"http://www.imdb.com/title/tt0103064/?ref_=nv_sr_3")

the_intouchables = media.Movie("The Intouchables",
	"A story of life",
	"http://ia.media-imdb.com/images/M/MV5BMTYxNDA3MDQwNl5BMl5BanBnXkFtZTcwNTU4Mzc1Nw@@._V1_SX640_SY720_.jpg",
	"https://www.youtube.com/watch?v=0V8ZJ_8qARs",
	"https://www.youtube.com/watch?v=cXu2MhWYUuE",
	"http://www.imdb.com/title/tt1675434/?ref_=nv_sr_1")

dangerous_beauty = media.Movie("Dangerous Beauty",
	"A unique woman during Renaissance",
	"http://ia.media-imdb.com/images/M/MV5BMTQzOTYyNDMzMV5BMl5BanBnXkFtZTYwODgzOTE5._V1_UY268_CR7,0,182,268_AL_.jpg",
	"https://www.youtube.com/watch?v=n_g4qspx3es",
	"https://www.youtube.com/watch?v=vyGyPNFMMdk",
	"http://www.imdb.com/title/tt0118892/?ref_=fn_al_tt_2")

the_rules_of_the_game = media.Movie("The rules of the game",
	"Humans and their society",
	"https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSa5q2lSNKDKIHA_Rpxv1c0iqBcCRxkuI5mDUbN7KMNmbjQriLmAA",
	"https://www.youtube.com/watch?v=qxs4P6u1EiI",
	"https://www.youtube.com/watch?v=JX1j7jeGfGY",
	"http://www.imdb.com/title/tt0031885/?ref_=nv_sr_1")

movies = [rocky, fight_club, terminator2, the_intouchables, dangerous_beauty, the_rules_of_the_game]

fresh_tomatoes.open_movies_page(movies)

#print (media.Movie.VALID_RATINGS)

#print media.Movie.__doc__

